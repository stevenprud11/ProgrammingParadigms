#! /bin/bash
set -e -x
javac *.java