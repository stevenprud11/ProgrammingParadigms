import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.util.Iterator;

import javax.imageio.ImageIO;


class Mario extends Sprite{
	int prevX, prevY;
	double vvel;
	int imageCount;
	int airTime;
	Image[] marioImages = null;
	Model model;
	
	Mario(Model m) throws IOException{
		
		model = m;
		h=95;
		w=60;
		coinblock=false;
		if(marioImages==null){
			marioImages = new Image[5];
			marioImages[0] = ImageIO.read(new File("mario1.png"));
			marioImages[1] = ImageIO.read(new File("mario2.png"));
			marioImages[2] = ImageIO.read(new File("mario3.png"));
			marioImages[3] = ImageIO.read(new File("mario4.png"));
			marioImages[4] = ImageIO.read(new File("mario5.png"));
		}

	}
	boolean doesCollide(int bx, int by, int bw, int bh){
		if(x + w < bx)
			return false;
		else if(x > bx + bw)
			return false;
		else if(y + h < by)
			return false;
		else if(y > by + bh)
			return false;
		else	
			return true;
	}
	void prevLocation(){
		prevX = x;
		prevY = y;
	}
	void getOut(int bx, int by, int bw, int bh, Sprite s) throws IOException{
		//my brick and mario both move on the camera so when a collision starts I have to stop moving both
		if(x + w > bx && prevX < bx && prevY + h > by && prevY < by + bh){ // coming from the left
			x-=4;
			for(int i = 0 ; i<model.sprites.size(); i++){
				Sprite b = model.sprites.get(i);
				b.x+=4;
			}
		}
		else if(x <= bx + bw && prevX + w > bx + bw && prevY + h > by && prevY < by + bh){// coming from the right
			x += 4;
			for(int i = 0 ; i<model.sprites.size(); i++){
				Sprite b = model.sprites.get(i);
				b.x-=4;
			}
		}
		else if(y + h >= by && prevY + h < by){// on top
			y = prevY;
			vvel=0;
			airTime=0;
		}
		else if(y <= by + bh && prevY > by + bh){// on bottom
			if(s.coinblock==true)
				((CoinBrick) s).createCoin();
			y = prevY;
			vvel=0;
		}
		
	}
	public void update() throws IOException{ //updates mario
		//adds gravity vvel and also adds velocity to the y position
		vvel +=3.14159;
		y+=vvel;
		//checks airtime
		if(vvel!=0)
			airTime++;
		else
			airTime=0;
		//iterates through sprites and checks for collision
		for(int i=0; i<model.sprites.size(); i++){
			Sprite b = model.sprites.get(i);
				if(b instanceof CoinBrick || b instanceof Brick)
					if(doesCollide(b.x, b.y, b.w, b.h)){
						getOut(b.x, b.y, b.w, b.h, b);
				}
		}
		//checks if he on the ground
		if(y>=500){
			vvel=0;
			airTime=0;
			y=500;
		}
		//stops mario off at the top of the screen
		if(y<0)
			vvel=0;	
	}
	
	void jumpMario(){
		//removes velocity when jumping checks for air time so no double jump
		if(airTime<5)
			vvel -= 10;
	}
	@Override
	public void draw(Graphics g, Sprite s){
		//draws mario image
		g.drawImage(marioImages[model.mario.imageCount], x-model.scrollPos, y, null);

	}
	
	Mario(Json ob, Model m) throws IOException{
    	model = m;
    	coinblock=false;
        x = (int)ob.getLong("x");
        y = (int)ob.getLong("y");
        w = (int)ob.getLong("w");
        h = (int)ob.getLong("h");
        imageCount = (int)ob.getLong("imageCount");
        if(marioImages==null){
			marioImages = new Image[5];
			marioImages[0] = ImageIO.read(new File("mario1.png"));
			marioImages[1] = ImageIO.read(new File("mario2.png"));
			marioImages[2] = ImageIO.read(new File("mario3.png"));
			marioImages[3] = ImageIO.read(new File("mario4.png"));
			marioImages[4] = ImageIO.read(new File("mario5.png"));
		}
    }
	    //marshaling a class object turns it into JSon format
	public Json marshal(){
       Json ob = Json.newObject();
	   ob.add("x", x);
       ob.add("y", y);
	   ob.add("w", w);
	   ob.add("h", h);
	   ob.add("imageCount", imageCount);

	   return ob;	        
	}
	
	
	public void tostring(){
		System.out.println("Mario " + x + " " + y + " " + w +  " " + h);
	}
}





