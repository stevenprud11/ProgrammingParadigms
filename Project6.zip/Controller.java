import java.awt.event.MouseListener;
import java.io.IOException;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

class Controller implements ActionListener, MouseListener, KeyListener{
	//instance variables
	View view;
	Model model;
	Mario mario;
	boolean keyLeft;
	boolean keyRight;
	boolean keyUp;
	boolean keyDown;
	boolean space;
	boolean coin;
	int mouseDownX, mouseDownY;

	

	//constructor
	Controller(Model m){
		model = m;
		coin = false;
		try {
			model.addBrick(500, 500, 100, 100);
			model.addBrick(500, 400, 100, 100);
			model.addBrick(400, 300, 100, 100);
			model.addBrick(300, 400, 100, 100);
			model.addCoinBrick(400, 50, 100, 100);
			model.addCoinBrick(700, 200, 100, 100);
			model.addBrick(700, 500, 100, 100);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	void setView(View v){
		view = v;
	}

	//mouse clicks
	public void mousePressed(MouseEvent e){
		mouseDownX = e.getX();
		mouseDownY = e.getY();
	}
	public void mouseReleased(MouseEvent e){ 
		int x1 = mouseDownX;
		int y1 = mouseDownY;
		int x2 = e.getX();
		int y2 = e.getY();

		int left = Math.min(x1,x2);
		int right = Math.max(x1,x2);
		int top = Math.min(y1,y2);
		int bottom = Math.max(y1,y2);
		//adds brick
		try {
			if(coin)
				model.addCoinBrick(left + model.scrollPos, top-25, right-left, bottom-top);
			else
				model.addBrick(left + model.scrollPos, top-25, right-left, bottom-top);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

	}
	public void mouseEntered(MouseEvent e){
	}
	public void mouseExited(MouseEvent e){
	}
	public void mouseClicked(MouseEvent e){
	}
	public void actionPerformed(ActionEvent e){
	}

	//clicks from keyboard
	public void keyPressed(KeyEvent e){
		switch(e.getKeyCode()){
			case KeyEvent.VK_RIGHT: keyRight = true; break;
			case KeyEvent.VK_LEFT: keyLeft = true; break;
			case KeyEvent.VK_UP: keyUp = true; break;
			case KeyEvent.VK_DOWN: keyDown = true; break;
			case KeyEvent.VK_SPACE: space = true; break;
			case KeyEvent.VK_C: coin = true; break;
			case KeyEvent.VK_V: coin = false; break;
		}
	}
	//released keys
	public void keyReleased(KeyEvent e){
		Json j;
		//checks for key release
		switch(e.getKeyCode()){
			case KeyEvent.VK_RIGHT: keyRight = false; break;
			case KeyEvent.VK_LEFT: keyLeft = false; break;
			case KeyEvent.VK_UP: keyUp = false; break;
			case KeyEvent.VK_DOWN: keyDown = false; break;
			case KeyEvent.VK_SPACE: space = false; break;
			case KeyEvent.VK_S: model.save("map.json"); 
				System.out.println("Game Saved"); break; //key s will save current view to map.json
			case KeyEvent.VK_L: try {
				model.unmarshal(j = Json.load("map.json"));
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} 
				System.out.println("Game Loaded From Previous Saved Game");
				//model.mario.y=500;			
				break; //key l will load map.json
		}
	}

	public void keyTyped(KeyEvent e){
	}
	void update(){
		//saves marios previous location
		((Mario) model.mario).prevLocation();	
		//mario jumps
		if(space){
			((Mario) model.mario).jumpMario();
		}
		//moves mario to the right
		if(keyRight){ 
			model.mario.x+=4;
			//moves bricks to the left
			for(int i = 0 ; i<model.sprites.size(); i++){
				Sprite b = model.sprites.get(i);
				b.x-=4;
			}
			//model.mario.tostring();
			//System.out.println(model.scrollPos);
			//rotates mario images
			model.mario.imageCount+=1;
			model.mario.imageCount = model.mario.imageCount%5;
		}
		//moves mario to the left
		if(keyLeft){
			model.mario.x-=4;
			//moves bricks to the right
			for(int i = 0 ; i<model.sprites.size(); i++){
				Sprite b = model.sprites.get(i);
				b.x+=4;
			}
			//rotates mario images
			model.mario.imageCount-=1;
			if(model.mario.imageCount<0){
				model.mario.imageCount=4;
			}
			//model.mario.tostring();
			//System.out.println(model.scrollPos);
		}
		

	}
}
