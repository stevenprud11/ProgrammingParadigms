import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Coin extends Sprite{
	Model model;	
	Image coin;
	int vvel;
	
	Coin(int xx, int yy, int ww, int hh, Model m){
		model = m;
		x = xx;
		y = yy;
		w = ww;
		h = hh;
		vvel=-10;
		coinblock=false;
		try{
			coin = ImageIO.read(new File("coin.jpeg"));
		}
		catch(IOException e){
			e.printStackTrace();
		}
	}
	@Override
	public void draw(Graphics g, Sprite s) {
		// TODO Auto-generated method stub
		g.drawImage(coin, s.x-model.scrollPos, s.y, s.w, s.h, null);
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub
		vvel+=1;
		y+=vvel;		
	}

	Coin(Json ob){
        x = (int)ob.getLong("x");
        y = (int)ob.getLong("y");
        w = (int)ob.getLong("w");
        h = (int)ob.getLong("h");
        try{
			coin = ImageIO.read(new File("coin.jpeg"));
		}
		catch(IOException e){
			e.printStackTrace();
		}
    }
    //marshaling a class object turns it into JSon format
	@Override
	public Json marshal() {
		// TODO Auto-generated method stub
		Json ob = Json.newObject();
        ob.add("x", x);
        ob.add("y", y);
        ob.add("w", w);
        ob.add("h", h);

        return ob;
	}

}
