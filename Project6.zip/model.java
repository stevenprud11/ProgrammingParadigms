import java.awt.Graphics;
import java.io.IOException;
import java.util.*;

class Model{
	int dest_x;
	int dest_y;
	int scrollPos = 0;
	Sprite brick;
	Sprite mario;
	ArrayList<Sprite> sprites;

	Model() throws IOException{
		mario = new Mario(this);
		sprites = new ArrayList<Sprite>();
		brick = new Brick(this);
		sprites.add(mario);
	}
	public void addBrick(int x, int y, int w, int h) throws IOException{
		Sprite b = new Brick(x,y,w,h, this);
		sprites.add(b);
	}
	public void addCoinBrick(int x, int y, int w, int h){
		Sprite c = new CoinBrick(x, y, w, h, this);
		sprites.add(c);
	}
//	public void loadDefault(Graphics g) throws IOException{
//		Sprite b = new Brick(500, 200, 50, 50, this);
//		sprites.add(b);
//		
//	}
	public void update() throws IOException{
		for(int i = 0; i < sprites.size(); i++){
			Sprite temp = sprites.get(i);
			temp.update();
			if(temp instanceof Coin){
				if(temp.y > 2000)
					sprites.remove(i);
			}
		}
		scrollPos = mario.x - 200;

	}

//	public void setDestination(int x, int y){
//		this.dest_x = x;
//		this.dest_y = y;
//	}
	//condensing into Json format
	Json marshal(){
		//takes Bricks list and makes a Json list full of them
		Json bricksList = Json.newList();
		Json coinbricksList = Json.newList();
		Json ob = Json.newObject();
		for(int i=0; i<sprites.size(); i++){
			if(sprites.get(i) instanceof Brick){
				Brick b = (Brick) sprites.get(i);
				Json j = b.marshal();
				bricksList.add(j);
				bricksList.add(j);
			}
			else if(sprites.get(i) instanceof CoinBrick){
				CoinBrick c = (CoinBrick) sprites.get(i);
				Json j = c.marshal();
				coinbricksList.add(j);
			}
			else if(sprites.get(i) instanceof Mario){
				Mario mario = (Mario) sprites.get(i);
				Json j = mario.marshal();
				ob.add("mario", j);
			}

		}
		
		ob.add("bricks", bricksList);
		ob.add("coinbricks", coinbricksList);
		return ob;
		
	}
	//turns Json into class object
	void unmarshal(Json ob) throws IOException{
		sprites.clear();
		Json mar = ob.get("mario");
		Sprite mario = new Mario(mar, this);
		sprites.add(mario);
		Json bricksList = ob.get("bricks");
		for(int i =0; i<bricksList.size(); i++){
			Json j = bricksList.get(i);
			Sprite b = new Brick(j, this);
			sprites.add(b);
		}
		Json coinbricksList = ob.get("coinbricks");
		for(int i =0; i<coinbricksList.size(); i++){
			Json j = coinbricksList.get(i);
			Sprite b = new CoinBrick(j, this);
			sprites.add(b);
		}
		
	}

	void save(String filename){
		Json ob = marshal();
		ob.save(filename);
	}
	void open(String filename){
		
	}
}