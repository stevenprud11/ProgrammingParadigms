import java.awt.Graphics;
import java.awt.Image;
import java.io.IOException;

public abstract class Sprite {
	int x;
	int y;
	int w;
	int h;
	boolean coinblock;
	int imageCount;
	
	public abstract void draw(Graphics g, Sprite s);
	public abstract void update() throws IOException;
	public abstract Json marshal();
	public void tostring() {
		// TODO Auto-generated method stub
		
	}

}
