#!/bin/bash
set -e -x
javac Game.java View.java Controller.java Model.java Brick.java Json.java Sprite.java Mario.java CoinBrick.java Coin.java
