import java.awt.event.MouseListener;
import java.io.IOException;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.util.ArrayList;


class Controller implements ActionListener, MouseListener, KeyListener{
	//instance variables
	View view;
	Model model;
	boolean keyLeft;
	boolean keyRight;
	boolean keyUp;
	boolean keyDown;
	boolean space;
	boolean coin;
	int mouseDownX, mouseDownY;

	

	//constructor
	Controller(Model m){
		model = m;
		coin = false;
		try { //adds original bricks for default map
			model.addBrick(300, 500, 100, 100);
			model.addBrick(400, 400, 400, 200);
			model.addCoinBrick(500, 100, 100, 100);
			model.addBrick(700, 175, 200, 100);
			model.addBrick(1000, 300, 100, 200);
			model.addCoinBrick(1200, 300, 100, 100);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//sets view
	void setView(View v){
		view = v;
	}
	//mouse clicks
	public void mousePressed(MouseEvent e){
		mouseDownX = e.getX();
		mouseDownY = e.getY();
	}
	//mouse realsed
	public void mouseReleased(MouseEvent e){ 
		int x1 = mouseDownX;
		int y1 = mouseDownY;
		int x2 = e.getX();
		int y2 = e.getY();

		int left = Math.min(x1,x2);
		int right = Math.max(x1,x2);
		int top = Math.min(y1,y2);
		int bottom = Math.max(y1,y2);
		//adds brick
		try {
			if(coin)
				model.addCoinBrick(left + model.scrollPos, top-25, right-left, bottom-top);
			else
				model.addBrick(left + model.scrollPos, top-25, right-left, bottom-top);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

	}
	//clicks from keyboard
	public void keyPressed(KeyEvent e){
		switch(e.getKeyCode()){
			case KeyEvent.VK_RIGHT: keyRight = true; break;
			case KeyEvent.VK_LEFT: keyLeft = true; break;
			case KeyEvent.VK_UP: keyUp = true; break;
			case KeyEvent.VK_DOWN: keyDown = true; break;
			case KeyEvent.VK_SPACE: space = true; break;
			case KeyEvent.VK_C: coin = true; break;
			case KeyEvent.VK_V: coin = false; break;
		}
	}
	//released keys
	public void keyReleased(KeyEvent e){
		Json j;
		//checks for key release
		switch(e.getKeyCode()){
			case KeyEvent.VK_RIGHT: keyRight = false; break;
			case KeyEvent.VK_LEFT: keyLeft = false; break;
			case KeyEvent.VK_UP: keyUp = false; break;
			case KeyEvent.VK_DOWN: keyDown = false; break;
			case KeyEvent.VK_SPACE: space = false; break;
			case KeyEvent.VK_S: model.save("map.json"); System.out.println("Game Saved"); break; //key s will save current view to map.json
			case KeyEvent.VK_L: 
				try {
					model.unmarshal(j = Json.load("map.json"));
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
				System.out.println("Game Loaded From Previous Saved Game"); break; //key l will load map.json
		}
	}

	//updates controller
	public void update() throws IOException{
		((Mario) model.mario).prevLocation();
		//Evaluate each possible action
		double score_run = model.evaluateAction(Model.Action.run, 0);
		double score_jump = model.evaluateAction(Model.Action.jump, 0);
		double score_jump_and_run =
			model.evaluateAction(Model.Action.run_jump, 0);

		// Do the best one
		//this loop checks to see if the block is empty to make sure mario stops jumping
		for(int i = 0; i<model.sprites.size(); i++){
			Sprite s = model.sprites.get(i);
			if(s instanceof CoinBrick)
				if(((CoinBrick) s).isEmpty && ((Mario)model.mario).y <= s.y + s.h && ((Mario)model.mario).prevY > s.y + s.h){
					score_jump_and_run = 0;
					score_jump = 0;}
		}
		//System.out.println(((Mario)model.mario).coin);
		if(score_jump_and_run > score_jump &&
				score_jump_and_run > score_run)
			model.doAction(Model.Action.run_jump);
		else if(score_jump > score_run)
			model.doAction(Model.Action.jump);
		else
			model.doAction(Model.Action.run);
		//saves marios previous location
		((Mario) model.mario).prevLocation();	
		//mario jumps
		if(space)
			((Mario) model.mario).jumpMario();
		//moves mario to the right
		if(keyRight){ 
			((Mario) model.mario).right();
		}
		//moves mario to the left
		if(keyLeft){
			((Mario) model.mario).left();
		}
		

	}
	public void keyTyped(KeyEvent e){
	}
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub	
	}
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
	}
	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
	}
}
