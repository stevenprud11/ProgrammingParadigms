import java.util.ArrayList;
import java.util.Iterator;

import javax.imageio.ImageIO;

import java.awt.*;
import java.io.File;
import java.io.IOException;


public class Brick extends Sprite{
    Model model;
    Image asteriod = null;
    
    
    
    public Brick(Model m) throws IOException{
    	model = m;
    	if(asteriod==null)
    		asteriod = ImageIO.read(new File("asteriod.png"));
    }
    public Brick(int xx, int yy, int ww, int hh, Model m) throws IOException{
        //using this.(variable name) makes it the largest variable possible in the class
    	model = m;
        x = xx;
        y = yy;
        w = ww;
        h = hh;
    	if(asteriod==null)
    		asteriod = ImageIO.read(new File("asteriod.png"));	
    }
    Brick(Brick that, Model m){
    	this.x = that.x;
		this.y = that.y;
		this.w = that.w;
		this.h = that.h;
    	this.model = m;

    }
    
    public Sprite cloneme(Model m){
		return new Brick(this, m);
	}
    //draws bricks from super class
    @Override
    public void draw(Graphics g, Sprite s){	//draws bricks
    	try {
			asteriod = ImageIO.read(new File("asteriod.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	if(s!=null)
    		g.drawImage(asteriod, s.x-model.scrollPos, s.y, s.w, s.h, null);
    }
    boolean isBrick(){return true;}
    //updating brick sprite
    @Override
	public void update() {
		// TODO Auto-generated method stub
    	
	}
    //unmarsheling brings the Json formatted object back into a class object
    Brick(Json ob, Model m) throws IOException{
    	model = m;
        x = (int)ob.getLong("x");
        y = (int)ob.getLong("y");
        w = (int)ob.getLong("w");
        h = (int)ob.getLong("h");
        asteriod = ImageIO.read(new File("asteriod.png"));
    }
    //marshaling a class object turns it into JSon format
    public Json marshal(){
        Json ob = Json.newObject();
        ob.add("x", x);
        ob.add("y", y);
        ob.add("w", w);
        ob.add("h", h);
        
        return ob;  
    }
    //prints out instance data for location of brick
    public void tostring(){
		System.out.println("Brick " + x + " " + y + " " + w +  " " + h);
	}
	

}