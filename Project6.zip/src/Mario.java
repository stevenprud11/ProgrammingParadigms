import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.util.Iterator;

import javax.imageio.ImageIO;


class Mario extends Sprite{
	int prevX, prevY;
	double vvel;
	int imageCount;
	int airTime;
	int timesJumped;
	int coin;
	
	Image[] marioImages = null;
	Model model;
	
	
	Mario(Model m) throws IOException{
		model = m;
		h=95;
		w=60;
		coin = 0;
		if(marioImages==null){
			marioImages = new Image[5];
			marioImages[0] = ImageIO.read(new File("mario1.png"));
			marioImages[1] = ImageIO.read(new File("mario2.png"));
			marioImages[2] = ImageIO.read(new File("mario3.png"));
			marioImages[3] = ImageIO.read(new File("mario4.png"));
			marioImages[4] = ImageIO.read(new File("mario5.png"));
		}
		timesJumped = 0;
	}
	//copy constructor
	Mario(Mario that, Model m){
		this.x = that.x;
		this.y = that.y;
		this.w = that.w;
		this.h = that.h;
		this.coin = that.coin;
		this.timesJumped = that.timesJumped;
		this.model = m;
		this.prevX = that.prevX;
		this.prevY = that.prevY;
		this.vvel = that.vvel;

	}
	
	public Sprite cloneme(Model m){
		return new Mario(this, m);
	}
	//previous location 
	//gets used in controller
	void prevLocation(){
		prevX = x;
		prevY = y;
	}
	//collision detection
	boolean doesCollide(int bx, int by, int bw, int bh){
		if(x + w < bx)
			return false;
		else if(x > bx + bw)
			return false;
		else if(y + h < by)
			return false;
		else if(y > by + bh)
			return false;
		else	
			return true;
	}
	//collision detection
	void getOut(int bx, int by, int bw, int bh, Sprite s) throws IOException{
		//my brick and mario both move on the camera so when a collision starts I have to stop moving both
		if(x + w > bx && prevX < bx && prevY + h > by && prevY < by + bh){ // coming from the left
			x-=6;
		}
		else if(x <= bx + bw && prevX + w > bx + bw && prevY + h > by && prevY < by + bh){// coming from the right
			x += 6;
		}
		else if(y + h >= by && prevY + h < by){// on top
			y = prevY;
			vvel=0;
			airTime=0;
		}
		else if(y <= by + bh && prevY > by + bh){// on bottom
			if((s.isCoinBrick() && !((CoinBrick)s).isEmpty)){
				((CoinBrick) s).createCoin();
				coin+=500;
			}
			y = prevY;
			vvel=0;
		}
	}
	//updates mario
	//calls collision detection
	//checks top and bottom of screen sets velocity
	public void update() throws IOException{ //updates mario
		//adds gravity vvel and also adds velocity to the y position
		vvel +=3.14159;
		y+=vvel;
		//checks airtime
		if(vvel!=0)
			airTime++;
		else
			airTime=0;
		//iterates through sprites and checks for collision
		for(int i=0; i<model.sprites.size(); i++){
			Sprite b = model.sprites.get(i);
				if(b instanceof CoinBrick || b instanceof Brick)
					if(doesCollide(b.x, b.y, b.w, b.h)){
						getOut(b.x, b.y, b.w, b.h, b);
				}
		}
		//checks if he on the ground
		if(y>=500){
			vvel=0;
			airTime=0;
			y=500;
		}
		//stops mario off at the top of the screen
		if(y<0)
			vvel=0;	
	}
	//draws mario
	@Override
	public void draw(Graphics g, Sprite s){
		//draws mario image
		g.drawImage(marioImages[model.mario.imageCount], x-model.scrollPos, y, null);

	}
	//jump method for mario
	void jumpMario(){
		//removes velocity when jumping 
		//checks for air time so no double jump
		if(airTime<1){
			vvel -= 40;
			timesJumped++;
		}
		//System.out.println(timesJumped);
	}
	public void right(){
		model.mario.x+=6;
		//rotates mario images
		model.mario.imageCount+=1;
		model.mario.imageCount = model.mario.imageCount%5;
	}
	public void left(){
		model.mario.x-=6;
		//rotates mario images
		model.mario.imageCount-=1;
		if(model.mario.imageCount<0){
			model.mario.imageCount=4;
		}
	}
	
	public boolean isMario(){
		return true;
	}
	
	
	//Json objects
	Mario(Json ob, Model m) throws IOException{
    	model = m;
        x = (int)ob.getLong("x");
        y = (int)ob.getLong("y");
        w = (int)ob.getLong("w");
        h = (int)ob.getLong("h");
        timesJumped = (int)ob.getLong("timesJumped");
        imageCount = (int)ob.getLong("imageCount");
        if(marioImages==null){
			marioImages = new Image[5];
			marioImages[0] = ImageIO.read(new File("mario1.png"));
			marioImages[1] = ImageIO.read(new File("mario2.png"));
			marioImages[2] = ImageIO.read(new File("mario3.png"));
			marioImages[3] = ImageIO.read(new File("mario4.png"));
			marioImages[4] = ImageIO.read(new File("mario5.png"));
		}
    }
	//marshaling a class object turns it into JSon format
	public Json marshal(){
       Json ob = Json.newObject();
	   ob.add("x", x);
       ob.add("y", y);
	   ob.add("w", w);
	   ob.add("h", h);
	   ob.add("imageCount", imageCount);
	   ob.add("timesJumped", timesJumped);

	   return ob;	        
	}
	//prints out instance data of mario location
	public void tostring(){
		System.out.println("Mario " + x + " " + y + " " + w +  " " + h);
	}
	public double getVVel(){
		return vvel;
	}
	public int getX(){
		return super.x;
	}
}





