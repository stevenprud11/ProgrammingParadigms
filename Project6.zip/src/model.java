import java.awt.Graphics;
import java.io.IOException;
import java.util.*;

class Model{
	int dest_x;
	int dest_y;
	int scrollPos = 0;
	Sprite brick;
	Sprite mario;
	ArrayList<Sprite> sprites;

	Model() throws IOException{
		mario = new Mario(this);
		sprites = new ArrayList<Sprite>();
		brick = new Brick(this);
		sprites.add(mario);
	}
	//deep copy
	public Model(Model that){
		this.dest_y = that.dest_x;
		this.dest_y = that.dest_y;
		this.scrollPos = that.scrollPos;
		this.sprites = new ArrayList<Sprite>();
		for(int i=0; i<that.sprites.size(); i++){
			Sprite s = that.sprites.get(i);
			Sprite clone = s.cloneme(this);
			sprites.add(clone);
			if(clone.isMario())
				this.mario = (Mario)clone;
		}
		
	}
	//adds bricks from controller
	public void addBrick(int x, int y, int w, int h) throws IOException{
		Sprite b = new Brick(x,y,w,h, this);
		sprites.add(b);
	}
	//adds coin bricks from controller
	public void addCoinBrick(int x, int y, int w, int h){
		Sprite c = new CoinBrick(x, y, w, h, this);
		sprites.add(c);
	}
	//updates model
	//updates all sprites
	public void update() throws IOException{
		for(int i = 0; i < sprites.size(); i++){
			Sprite temp = sprites.get(i);
			temp.update();
			if(temp instanceof Coin){
					if(temp.y > 2000)
						sprites.remove(i);
						
			}
		}
		scrollPos = mario.x - 200;

	}
	double evaluateAction(Action action, int depth) throws IOException
	{
		// Evaluate the state
		if(depth >= 10)
			return mario.x + 5000 * ((Mario)mario).coin - 2 * ((Mario)mario).timesJumped;

		// Simulate the action
		Model copy = new Model(this); // uses the copy constructor
		copy.doAction(action); // like what Controller.update did before
		copy.update(); // advance simulated time

		// Recurse
		if(depth % 7 != 0)
		   return copy.evaluateAction(action, depth + 1);
		else
		{
		   double best = copy.evaluateAction(Action.run, depth + 1);
		   best = Math.max(best,
			   copy.evaluateAction(Action.jump, depth + 1));
		   best = Math.max(best,
			   copy.evaluateAction(Action.run_jump, depth + 1));
		   return best;
		}
	}
	
	
	
	
	
	public void doAction(Action i){
		if(i == Action.run){
			((Mario)mario).right();
		}
		else if(i == Action.jump){
			((Mario)mario).jumpMario();
		}
		else if( i == Action.run_jump){
			((Mario)mario).jumpMario();
			((Mario)mario).right();
		}
	}
	
	
	enum Action{
		run,
		jump,
		run_jump;
	}
	
	//condensing into Json format
	Json marshal(){
		//takes Bricks list and makes a Json list full of them
		Json bricksList = Json.newList();
		Json coinbricksList = Json.newList();
		Json ob = Json.newObject();
		for(int i=0; i<sprites.size(); i++){
			if(sprites.get(i) instanceof Brick){
				Brick b = (Brick) sprites.get(i);
				Json j = b.marshal();
				bricksList.add(j);
				bricksList.add(j);
			}
			else if(sprites.get(i) instanceof CoinBrick){
				CoinBrick c = (CoinBrick) sprites.get(i);
				Json j = c.marshal();
				coinbricksList.add(j);
			}
			else if(sprites.get(i) instanceof Mario){
				Mario mario = (Mario) sprites.get(i);
				Json j = mario.marshal();
				ob.add("mario", j);
			}

		}
		
		ob.add("bricks", bricksList);
		ob.add("coinbricks", coinbricksList);
		return ob;
		
	}
	//turns Json into class object
	void unmarshal(Json ob) throws IOException{
		sprites.clear();
		Json mar = ob.get("mario");
		Sprite mario = new Mario(mar, this);
		sprites.add(mario);
		Json bricksList = ob.get("bricks");
		for(int i =0; i<bricksList.size(); i++){
			Json j = bricksList.get(i);
			Sprite b = new Brick(j, this);
			sprites.add(b);
		}
		Json coinbricksList = ob.get("coinbricks");
		for(int i =0; i<coinbricksList.size(); i++){
			Json j = coinbricksList.get(i);
			Sprite b = new CoinBrick(j, this);
			sprites.add(b);
		}
		
	}

	void save(String filename){
		Json ob = marshal();
		ob.save(filename);
	}
	void open(String filename){
		
	}
}