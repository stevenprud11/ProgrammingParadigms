import java.awt.Graphics;
import java.awt.Image;
import java.io.IOException;

public abstract class Sprite {
	int x;
	int y;
	int w;
	int h;
	int imageCount;
	
	boolean isBrick(){return false;}
	boolean isMario(){return false;}
	boolean isCoinBrick(){return false;}
	boolean isCoin(){return false;}
	
	public abstract void draw(Graphics g, Sprite s);
	public abstract void update() throws IOException;
	public abstract Json marshal();
	public abstract Sprite cloneme(Model m);

	public void tostring() {
		// TODO Auto-generated method stub
		
	}

}
