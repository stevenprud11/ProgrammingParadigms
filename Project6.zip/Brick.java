import java.util.ArrayList;
import java.util.Iterator;

import javax.imageio.ImageIO;

import java.awt.*;
import java.io.File;
import java.io.IOException;


public class Brick extends Sprite{
    Model model;
    Image asteriod = null;
    
    
    
    public Brick(Model m) throws IOException{
    	model = m;
    	if(asteriod==null)
    		asteriod = ImageIO.read(new File("asteriod.png"));
    }
    public Brick(int xx, int yy, int ww, int hh, Model m) throws IOException{
        //using this.(variable name) makes it the largest variable possible in the class
    	model = m;
        x = xx;
        y = yy;
        w = ww;
        h = hh;
        coinblock = false;
    	if(asteriod==null)
    		asteriod = ImageIO.read(new File("asteriod.png"));
    		
    }
    @Override
    public void draw(Graphics g, Sprite s){	//draws bricks
    	try {
			asteriod = ImageIO.read(new File("asteriod.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	if(s!=null)
    		g.drawImage(asteriod, s.x-model.scrollPos, s.y, s.w, s.h, null);
    }
    public void drawDefault(Graphics g, Model m, Sprite b) throws IOException{
    	g.drawImage(asteriod, b.x-model.scrollPos, b.y, b.w, b.h, null);
    }
    //updating brick sprite
    @Override
	public void update() {
		// TODO Auto-generated method stub
    	
	}
    //unmarsheling brings the Json formatted object back into a class object
    Brick(Json ob, Model m) throws IOException{
    	model = m;
    	coinblock=false;
        x = (int)ob.getLong("x");
        y = (int)ob.getLong("y");
        w = (int)ob.getLong("w");
        h = (int)ob.getLong("h");
        asteriod = ImageIO.read(new File("asteriod.png"));
    }
    //marshaling a class object turns it into JSon format
    public Json marshal(){
        Json ob = Json.newObject();
        ob.add("x", x);
        ob.add("y", y);
        ob.add("w", w);
        ob.add("h", h);

        return ob;
        
    }
    public void tostring(){
		System.out.println("Brick " + x + " " + y + " " + w +  " " + h);
	}
	

}