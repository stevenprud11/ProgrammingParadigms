import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.lang.reflect.Array;
import java.io.File;
import javax.swing.JButton;
import java.awt.Color;
import java.util.ArrayList;
import java.awt.*;

class View extends JPanel
{
	//instance variables
	JButton b1;
	Model model;
	Image background = null;

	//constructor
	View(Controller c, Model m) throws IOException{
		model = m;
		if(background==null){
			background = ImageIO.read(new File("background.jpg"));
		}
			

	}
	//removes button
//	void removeButton(){
//		this.remove(b1);
//		this.repaint();
//	}
	//paints image
	public void paintComponent(Graphics g){
		//setting background
		g.drawImage(background, 0+model.scrollPos/2, 0, null);
		//setting ground
		g.setColor(Color.GRAY); 
		g.fillRect(0, 595, 4000, 300);
		//drawing mario
//		try {
//			model.loadDefault(g);
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		for(int i = 0; i<model.sprites.size(); i++){
			Sprite s = model.sprites.get(i);
			s.draw(g, s);
		}
		
	}
}
