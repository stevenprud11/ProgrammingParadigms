import pygame
import time

from pygame.locals import*
from time import sleep

class Mario():
	def __init__(self, model, x, y):
		self.x = x
		self.y = y
		self.w = 65
		self.h = 90
		self.model = model
		self.imgArr = [pygame.image.load("mario1.png"), pygame.image.load("mario2.png"), pygame.image.load("mario3.png"), pygame.image.load("mario4.png"), pygame.image.load("mario5.png")]
		self.imgArr[0] = pygame.transform.scale(self.imgArr[0],(self.w,self.h))
		self.imgArr[1] = pygame.transform.scale(self.imgArr[1],(self.w,self.h))
		self.imgArr[2] = pygame.transform.scale(self.imgArr[2],(self.w,self.h))
		self.imgArr[3] = pygame.transform.scale(self.imgArr[3],(self.w,self.h))
		self.imgArr[4] = pygame.transform.scale(self.imgArr[4],(self.w,self.h))
		self.currentImg = 0
		self.vvel = 0
		self.airTime = 0
		self.prevX = 0
		self.prevY = 0

	def prevLocation(self, x, y):
		self.prevX = x
		self.prevY = y

	def doesCollide(self, s):
		if self.x + self.w < s.x:
			return False
		elif self.x > s.x + s.w:
			return False
		elif self.y + self.h < s.y:
			return False
		elif self.y > s.y + s.h:
			return False
		else:	
			return True

	def getOut(self, s):
        #my brick and mario both move on the camera so when a collision starts I have to stop moving both
		if self.x + self.w > s.x and self.prevX <= s.x and self.prevY + self.h >= s.y and self.prevY <= s.y + s.h:# coming from the left
			self.x-=8
		elif self.x <= s.x + s.w and self.prevX + self.w > s.x + s.w and self.prevY + self.h > s.y and self.prevY < s.y + s.h: #coming from the right
			self.x += 8
		elif self.y + self.h >= s.y and self.prevY + self.h < s.y: #// on top
			self.y = self.prevY
			self.vvel=0
			self.airTime=0
		elif self.y <= s.y + s.h and self.prevY > s.y + s.h: #// on bottom
			if s.coinBrick and s.numCoins!=0:
				s.createCoin()
			self.y = self.prevY
			self.vvel=0

	def update(self):
		self.vvel += 3
		self.y += self.vvel
		if self.vvel != 0:
			self.airTime+=1
		else:
			self.airTime = 0
		#collision detection
		for x in self.model.objArr:
			if self.doesCollide(x):
				self.getOut(x)
		if self.y >= 500:
			self.vvel = 0
			self.airTime = 0
			self.y = 500
		if self.y < 0:
			self.vvel=0

	def moveRight(self):
		self.x+=4
		self.model.moveRight()
		if self.currentImg < 4:
			self.currentImg += 1
		else:
			self.currentImg = 0
	
	def moveLeft(self):
		self.x-=4
		self.model.moveLeft()
		self.currentImg -= 1
		if self.currentImg < 0:
			self.currentImg = 4
	
	def jump(self):
		if self.airTime < 1:
			self.vvel -= 30



class Brick():
	def __init__(self, model, x, y):
		self.x = x
		self.y = y
		self.w = 100
		self.h = 100
		self.model = model
		self.img = pygame.image.load("asteriod.png")
		self.img = pygame.transform.scale(self.img,(self.w,self.h))
		self.coinBrick = False

	def moveRight(self):
		self.x-=4
	
	def moveLeft(self):
		self.x+=4

	def update(self):
		self.coinBrick = False

class CoinBrick():
	def __init__(self, model, x, y):
		self.model = model
		self.x = x
		self.y = y
		self.w = 100
		self.h = 100
		self.coinBrick = True
		self.numCoins = 5
		self.img = pygame.image.load("CoinBlock.png")
		self.img = pygame.transform.scale(self.img,(self.w,self.h))

	def moveRight(self):
		self.x-=4

	def moveLeft(self):
		self.x+=4
	
	def createCoin(self):
		if self.numCoins!=0:
			self.coin = Coin(self, self.x, self.y, 50, 50)
			self.model.objArr.append(self.coin)
		self.numCoins-=1
	
	def update(self):
		if self.numCoins == 0:
			self.img = pygame.image.load("emptyCoin.png")
			self.img = pygame.transform.scale(self.img,(self.w,self.h))


class Coin():
	def __init__(self, coinBrick, x, y, w, h):
		self.x = x
		self.y = y
		self.w = w
		self.h = h
		self.vvel = 0
		self.coinBrick = coinBrick
		self.img = pygame.image.load("coin.png")
		self.img = pygame.transform.scale(self.img, (self.w, self.h))
	
	def update(self):
		self.vvel +=5
		self.y += self.vvel

	def moveRight(self):
		self.x-=4

	def moveLeft(self):
		self.x+=4
	


class Model():
	def __init__(self):
		self.mario = Mario(self, 200, 100)
		self.brick = Brick(self, 300, 200)
		self.brick1 = Brick(self, 400, 300)
		self.coinBrick = CoinBrick(self, 500, 300)
		self.brick2 = Brick(self, 700, 500)
		self.objArr = []
		self.scrollPos = 200
		self.objArr.append(self.brick)
		self.objArr.append(self.brick1)
		self.objArr.append(self.coinBrick)
		self.objArr.append(self.brick2)

	def update(self):
		self.mario.prevLocation(self.mario.x, self.mario.y)
		self.mario.update()
		self.scrollPos = self.mario.x - 200
		
		for x in self.objArr:
			x.update()
	
	def moveRight(self):
		for x in self.objArr:
			x.moveRight()

	def moveLeft(self):
		for x in self.objArr:
			x.moveLeft()

class View():
	def __init__(self, model):
		screen_size = (1000,700)
		self.screen = pygame.display.set_mode(screen_size, 32)
		self.model = model

	def update(self):    
		self.screen.fill([0,200,100])
		self.screen.blit(self.model.mario.imgArr[self.model.mario.currentImg], (self.model.mario.x - self.model.scrollPos, self.model.mario.y))
		self.image = pygame.image.load("asteriod.png")
		self.image = pygame.transform.scale(self.image,(10000,300))
		self.screen.blit(self.image, (0,600))
		for o in self.model.objArr:
			self.screen.blit(o.img, (o.x-self.model.scrollPos, o.y))
		pygame.display.flip()

class Controller():
	def __init__(self, model):
		self.model = model
		self.keep_going = True

	def update(self):
		for event in pygame.event.get():
			if event.type == QUIT:
				self.keep_going = False
			elif event.type == KEYDOWN:
				if event.key == K_ESCAPE:
					self.keep_going = False
			elif event.type == pygame.MOUSEBUTTONUP:
				self.model.set_dest(pygame.mouse.get_pos())
		keys = pygame.key.get_pressed()
		if keys[K_LEFT]:
			self.model.mario.moveLeft()
		if keys[K_RIGHT]:
			self.model.mario.moveRight()
		if keys[K_UP]:
			self.model.mario.jump()

print("Use the arrow keys to move. Press Esc to quit.")
pygame.init()
m = Model()
v = View(m)
c = Controller(m)
pygame.draw.rect(v.screen, (225,225,225), (0,500,2000,300), 1)
while c.keep_going:
	c.update()
	m.update()
	v.update()
	sleep(0.004)
print("Goodbye")